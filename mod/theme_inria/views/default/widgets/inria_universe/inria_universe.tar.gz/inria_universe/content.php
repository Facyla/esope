<?php
/**
 * Elgg pages widget
 *
 * @package ElggPages
 */

//$num = (int) $vars['entity']->pages_num;

?>
<ul>
	<li><a target="blank" href="https://gforge.inria.fr/"><?php echo elgg_echo('theme_inria:topbar:forge'); ?></a></li>
	<li><a target="blank" href="https://notepad.inria.fr/"><?php echo elgg_echo('theme_inria:topbar:notepad'); ?></a></li>
	<li><a target="blank" href="http://www.framadate.org/"><?php echo elgg_echo('theme_inria:topbar:framadate'); ?></a></li>
	<li><a target="blank" href="http://qlf-devinar.inria.fr/"><?php echo elgg_echo('theme_inria:topbar:webinar'); ?></a></li>
	<li><a target="blank" href="https://transfert.inria.fr/"><?php echo elgg_echo('theme_inria:topbar:ftp'); ?></a></li>
	<li><a target="blank" href="https://partage.inria.fr"><?php echo elgg_echo('theme_inria:topbar:share'); ?></a></li>
	<li><a target="blank" href="http://intranet.irisa.fr/irisa/services/pavu/documentation/audioconf#resa"><?php echo elgg_echo('theme_inria:topbar:confcall'); ?></a></li>
	<li><a target="blank" href="http://dsi.inria.fr/services_offerts/visio/EVO">EVO</a></li>
	<li><a target="blank" href="https://sympa-roc.inria.fr/"><?php echo elgg_echo('theme_inria:topbar:mailinglist'); ?></a></li>
</ul>

