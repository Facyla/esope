<?php

echo 'This text is displayed by an external script.<br>';

?>